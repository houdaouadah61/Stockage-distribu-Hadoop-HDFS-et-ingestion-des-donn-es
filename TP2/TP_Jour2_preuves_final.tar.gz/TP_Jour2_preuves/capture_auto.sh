#!/bin/bash
DOSSIER="$HOME/TP_Jour2_preuves"

while true; do
    DATE=$(date +%Y%m%d_%H%M%S)

    {
        echo "=== DATE ==="
        date

        echo "=== SERVICES HADOOP ==="
        jps

        echo "=== ETAT HDFS ==="
        hdfs dfsadmin -report

        echo "=== DOSSIERS DATA LAKE ==="
        hdfs dfs -ls -R /retail-lake

        echo "=== FICHIERS DEPOSES PAR NIFI ==="
        hdfs dfs -ls -h /retail-lake/raw/nifi

        echo "=== ETAT NIFI ==="
        /opt/nifi/bin/nifi.sh status
    } > "$DOSSIER/etat_$DATE.txt" 2>&1

    if command -v gnome-screenshot >/dev/null 2>&1; then
        gnome-screenshot -f "$DOSSIER/ecran_$DATE.png" 2>/dev/null
    fi

    sleep 180
done
